import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hen extends Actor
{
    /**
     * Act - do whatever the Ant wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GreenfootImage image1 = new GreenfootImage("hen1.png");
    GreenfootImage image2 = new GreenfootImage("hen2.png");
    public void act() 
    {
        checkKeyPress();
    }    
    
    public void checkKeyPress(){
        if(Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY() - 1);
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY() + 1);
        }
        if(Greenfoot.isKeyDown("left")){
            setImage(image1);
            setLocation(getX() - 1, getY());
        }
        if(Greenfoot.isKeyDown("right")){
            setImage(image2);
            setLocation(getX() + 1, getY());
        }
    }
}
